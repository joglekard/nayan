package com.example.voterlist;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class VoterRepository {

    private EmployeeDao employeeDao;
    private LiveData<List<EmployeeData>> listData;




    public VoterRepository(Application application)
    {
        listData=DatabaseClass.getDatabase(application).getDao().getListData();
         employeeDao =DatabaseClass.getDatabase(application).getDao();

    }
    public LiveData<List<EmployeeData>> getListData()
    {
        return listData;
    }

    public LiveData<EmployeeData> getdatabyId(int id)
    {
       LiveData<EmployeeData> edata= employeeDao.getRow(id);
        return edata;

    }


//
//  public void insert(EmployeeData employeeData)
//  {
//      new InsertAsyncTask((employeeDao)).execute(employeeData);
//  }
//
//  private static class InsertAsyncTask extends AsyncTask<EmployeeData,Void, Void> {
//      private EmployeeDao employeedao;
//
//      private InsertAsyncTask(EmployeeDao employeedao) {
//          this.employeedao = employeedao;
//      }
//
//      @Override
//      protected Void doInBackground(EmployeeData... employeeData) {
//          employeedao.insertAllData(employeeData[0]);
//          return null;
//      }
//  }
}