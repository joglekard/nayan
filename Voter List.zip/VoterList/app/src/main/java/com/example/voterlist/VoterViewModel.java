package com.example.voterlist;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.List;

public class VoterViewModel extends AndroidViewModel {




    public LiveData<List<EmployeeData>> viewlist;
    private ArrayList<RecyclerData> recyclerDataArrayList;
    public VoterRepository voterRepository;
    public LiveData<EmployeeData> employeeData;


    public VoterViewModel(@NonNull Application application) {
        super(application);

        voterRepository= new VoterRepository(application);


    }

    public LiveData<List<EmployeeData>> viewget()
    {

        //Retrieving some specific data from database and storing it in list
        viewlist=voterRepository.getListData();
        return viewlist;


    }

    public LiveData<EmployeeData> viewDetails(int id)
    {  return voterRepository.getdatabyId(id);


    }


}




