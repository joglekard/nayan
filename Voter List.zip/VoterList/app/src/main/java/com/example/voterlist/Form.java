package com.example.voterlist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Form  extends AppCompatActivity {
    EditText e_id,e_firstname,e_lastname,e_age,e_bloodgroup,e_dob,e_phone,e_email,e_street,e_city,e_state,e_country,e_zipcode,e_marital,e_aadhar,e_pan,e_father,e_mother;
    Button save,back;
    int flag=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        e_id=findViewById(R.id.edit_text1);
        e_firstname=findViewById(R.id.edit_text2);
        e_lastname=findViewById(R.id.edit_text3);
        e_age=findViewById(R.id.edit_text4);
        e_bloodgroup=findViewById(R.id.edit_text5);
        e_dob=findViewById(R.id.edit_text6);
        e_phone=findViewById(R.id.edit_text7);
        e_email=findViewById(R.id.edit_text8);
        e_street=findViewById(R.id.edit_text9);
        e_city=findViewById(R.id.edit_text10);
        e_state=findViewById(R.id.edit_text11);
        e_country=findViewById(R.id.edit_text12);
        e_zipcode=findViewById(R.id.edit_text13);
        e_marital=findViewById(R.id.edit_text14);
        e_aadhar=findViewById(R.id.edit_text15);
        e_pan=findViewById(R.id.edit_text16);
        e_father=findViewById(R.id.edit_text17);
        e_mother=findViewById(R.id.edit_text18);

        save=findViewById(R.id.save);
        back=findViewById(R.id.back);

        save.setOnClickListener((view)->{validate();});
        back.setOnClickListener((view)->{  startActivity(new Intent(getApplicationContext(),MainActivity.class));});


}
public void validate() {
    String id_txt = e_id.getText().toString().trim();
    String firstname_txt = e_firstname.getText().toString().trim();
    String lastname_txt = e_lastname.getText().toString().trim();
    String age_txt = e_age.getText().toString().trim();
    String bloodgroup_txt = e_bloodgroup.getText().toString().trim();
    String dob_txt = e_dob.getText().toString().trim();
    String phone_txt = e_phone.getText().toString().trim();
    String email_txt = e_email.getText().toString().trim();
    String street_txt = e_street.getText().toString().trim();
    String city_txt = e_city.getText().toString().trim();
    String state_txt = e_state.getText().toString().trim();
    String country_txt = e_country.getText().toString().trim();
    String zipcode_txt = e_zipcode.getText().toString().trim();
    String marital_txt = e_marital.getText().toString().trim();
    String aadhar_txt = e_aadhar.getText().toString().trim();
    String pan_txt = e_pan.getText().toString().trim();
    String father_txt = e_father.getText().toString().trim();
    String mother_txt = e_mother.getText().toString().trim();


    if (id_txt.length() != 4) {
        e_id.requestFocus();
        e_id.setError("Please enter 4 digit number only");
        flag = 1;
    }
    if (!id_txt.matches("[0-9]+")) {
        e_id.requestFocus();
        e_id.setError("ID should be a number");
        flag = 1;
    }

    if (!firstname_txt.matches("[A-Z]([a-z]+|[A-Z]+)")) {
        e_firstname.requestFocus();
        e_firstname.setError("Invalid Firstname");
        flag = 1;
    }
    if (firstname_txt.length() == 0) {
        e_firstname.requestFocus();
        e_firstname.setError("Field cannot be empty");
        flag = 1;
    }
    if (lastname_txt.length() == 0) {
        e_lastname.requestFocus();
        e_lastname.setError("Field cannot be empty");
        flag = 1;
    }
    if (!lastname_txt.matches("[a-zA-Z]+")) {
        e_lastname.requestFocus();
        e_lastname.setError("Invalid Lastname");
        flag = 1;
    }
    if (dob_txt.length() == 0) {
        e_dob.requestFocus();
        e_dob.setError("Field cannot be empty");
        flag = 1;
    }
    if (!dob_txt.matches("0[1-9]|1[0-2]|3[01]/0[1-9]|[12][0-9]|/[0-9]{4}" )){
        e_dob.requestFocus();
        e_dob.setError("Invalid Date Of Birth");
        flag = 1;
    }
    if (phone_txt.length() == 0) {
        e_phone.requestFocus();
        e_phone.setError("Field cannot be empty");
        flag = 1;
    }
    if (!phone_txt.matches("^[2-9]{1}[0-9]{9}$")) {
        e_phone.requestFocus();
        e_phone.setError("Invalid Phone Number");
        flag = 1;
    }
    if (email_txt.length() == 0) {
        e_email.requestFocus();
        e_email.setError("Field cannot be empty");
        flag = 1;
    }
    if (!email_txt.matches("^[a-zA-Z0-9_+&*-] + (?:\\\\.[a-zA-Z0-9_+&*-]\n" +
            "+ )*@(?:[a-zA-Z0-9-]+\\\\.) + [a-zA-Z]{2,7}$")) {
        e_email.requestFocus();
        e_email.setError("Invalid email");
        flag = 1;
    }
    if (street_txt.length() == 0) {
        e_street.requestFocus();
        e_street.setError("Field cannot be empty");
        flag = 1;
    }
    if (!state_txt.matches("[a-zA-Z]+")) {
        e_street.requestFocus();
        e_street.setError("Invalid");
        flag = 1;
    }
    if (city_txt.length() == 0) {
        e_city.requestFocus();
        e_city.setError("Field cannot be empty");
        flag = 1;
    }
    if (!city_txt.matches("[a-zA-Z]+")) {
        e_city.requestFocus();
        e_city.setError("Invalid");
        flag = 1;
    }
    if (country_txt.length() == 0) {
        e_country.requestFocus();
        e_country.setError("Field cannot be empty");
        flag = 1;
    }
    if (!country_txt.matches("[a-zA-Z]+")) {
        e_country.requestFocus();
        e_country.setError("Invalid");
        flag = 1;
    }
    if (zipcode_txt.length() != 6) {
        e_zipcode.requestFocus();
        e_zipcode.setError("Please enter 4 digit number only");
        flag = 1;
    }
    if (!zipcode_txt.matches("^[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}$")) {
        e_zipcode.requestFocus();
        e_zipcode.setError("Invalid Zipcode");
        flag = 1;
    }
    if (marital_txt.length() == 0) {
        e_marital.requestFocus();
        e_marital.setError("Field cannot be empty");
        flag = 1;
    }
    if (!marital_txt.matches("[married|unmarried|Married|Unmarried]")) {
        e_marital.requestFocus();
        e_marital.setError("Invalid");
        flag = 1;
    }
if(flag==0){
    saveData();
}


}

public void saveData(){

        EmployeeData model = new EmployeeData();


//    model.setid(id_txt);
//    model.setFirstname(firstname_txt);
//    model.setLastname(lastname_txt);
//    model.setAge(age_txt);
//    model.setBloodgroup(bloodgroup_txt);

    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

    e_id.setText("");
    e_firstname.setText("");
    e_lastname.setText("");
    e_age.setText("");
    e_bloodgroup.setText("");
    e_age.setText("");
    Toast.makeText(this, "Data Successfully Saved", Toast.LENGTH_SHORT).show();

}
}


