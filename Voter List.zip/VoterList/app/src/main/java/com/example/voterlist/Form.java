package com.example.voterlist;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Form  extends AppCompatActivity {
    EditText e_voterid,e_firstname,e_lastname,e_age,e_bloodgroup,e_dob,e_phone,e_email,e_street,e_city,e_state,e_country,e_zipcode,e_marital,e_aadhar,e_pan,e_father,e_mother;

    //For displaying calender
    final Calendar myCalendar = Calendar.getInstance();
    final DatePickerDialog.OnDateSetListener date = (view, year, monthOfYear, dayOfMonth) -> {
        // TODO Auto-generated method stub
        myCalendar.set(Calendar.YEAR, year);
        myCalendar.set(Calendar.MONTH, monthOfYear);
        myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        updateLabel();
    };
    private void updateLabel() {
        String myFormat = "dd/MM/yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        e_dob.setText(sdf.format(myCalendar.getTime()));
    }//calender



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.save, menu);
        return true;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        e_dob=findViewById(R.id.edit_text6);
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        //calender
        e_dob.setOnClickListener(v -> {
                  //TODO Auto-generated method stub
           new DatePickerDialog(Form.this, date, myCalendar
                   .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                   myCalendar.get(Calendar.DAY_OF_MONTH)).show();
       });//calender
        e_voterid=findViewById(R.id.edit_text1);
        e_firstname=findViewById(R.id.edit_text2);
        e_lastname=findViewById(R.id.edit_text3);
        e_age=findViewById(R.id.edit_text4);
        e_bloodgroup=findViewById(R.id.edit_text5);
      //  e_dob=findViewById(R.id.edit_text6);
        e_phone=findViewById(R.id.edit_text7);
        e_email=findViewById(R.id.edit_text8);
        e_street=findViewById(R.id.edit_text9);
        e_city=findViewById(R.id.edit_text10);
        e_state=findViewById(R.id.edit_Text11);
        e_country=findViewById(R.id.edit_text12);
        e_zipcode=findViewById(R.id.edit_text13);
        e_marital=findViewById(R.id.edit_text14);
        e_aadhar=findViewById(R.id.edit_text15);
        e_pan=findViewById(R.id.edit_text16);
        e_father=findViewById(R.id.edit_text17);
        e_mother=findViewById(R.id.edit_text18);

}
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.save){
            validate();
        }
        if(item.getItemId()==android.R.id.home) {
            Toast.makeText(getApplicationContext(), "Back Button Clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
public void validate() {
        //Storing the input entered by user in different strings.
    String voterid_txt = e_voterid.getText().toString().trim();
    String firstname_txt = e_firstname.getText().toString().trim();
    String lastname_txt = e_lastname.getText().toString().trim();
    String age_txt = e_age.getText().toString().trim();
    String bloodgroup_txt = e_bloodgroup.getText().toString().trim();
    String dob_txt = e_dob.getText().toString().trim();
    String phone_txt = e_phone.getText().toString().trim();
    String email_txt = e_email.getText().toString().trim();
    String street_txt = e_street.getText().toString().trim();
    String city_txt = e_city.getText().toString().trim();
    String state_txt = e_state.getText().toString().trim();
    String country_txt = e_country.getText().toString().trim();
    String zipcode_txt = e_zipcode.getText().toString().trim();
    String marital_txt = e_marital.getText().toString().trim();
    String aadhar_txt = e_aadhar.getText().toString().trim();
    String pan_txt = e_pan.getText().toString().trim();
    String father_txt = e_father.getText().toString().trim();
    String mother_txt = e_mother.getText().toString().trim();


//  int flag=0;
//    if (!voterid_txt.matches("[0-9]+")) {
//        e_voterid.requestFocus();
//        e_voterid.setError("ID should be a number");
//        flag = 1;
//    }
//    if (voterid_txt.length() != 4) {
//        e_voterid.requestFocus();
//        e_voterid.setError("Please enter 4 digit number only");
//        flag = 1;
//    }
//    if (!firstname_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
//        e_firstname.requestFocus();
//        e_firstname.setError("Invalid Firstname");
//        flag = 1;
//    }
//    if (firstname_txt.length() == 0) {
//        e_firstname.requestFocus();
//        e_firstname.setError("Field cannot be empty");
//        flag = 1;
//    }
//    if (!lastname_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
//        e_lastname.requestFocus();
//        e_lastname.setError("Invalid Lastname");
//        flag = 1;
//    }
//    if (lastname_txt.length() == 0) {
//        e_lastname.requestFocus();
//        e_lastname.setError("Field cannot be empty");
//        flag = 1;
//    }
//    if (!dob_txt.matches("(0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01])/((?:19|20)[0-9][0-9])" )){
//        e_dob.requestFocus();
//        e_dob.setError("Invalid Date Of Birth");
//        flag = 1;
//    }
//    if (dob_txt.length() == 0) {
//        e_dob.requestFocus();
//        e_dob.setError("Field cannot be empty");
//        flag = 1;
//    }
//    if (!phone_txt.matches("[2-9][0-9]{9}")) {
//        e_phone.requestFocus();
//        e_phone.setError("Invalid Phone Number");
//        flag = 1;
//    }
//    if (phone_txt.length() == 0) {
//        e_phone.requestFocus();
//        e_phone.setError("Field cannot be empty");
//        flag = 1;
//    }
//
//    if (age_txt.matches("[a-zA-Z]+")) {
//        e_age.requestFocus();
//        e_age.setError("Age should be in digits");
//        flag = 1;
//    }
//    if (age_txt.length() == 0) {
//        e_age.requestFocus();
//        e_age.setError("Field cannot be empty");
//        flag = 1;
//    }
//    if (!email_txt.matches("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$")) {
//        e_email.requestFocus();
//        e_email.setError("Invalid email");
//        flag = 1;
//    }
//
//    if (email_txt.length() == 0) {
//        e_email.requestFocus();
//        e_email.setError("Field cannot be empty");
//        flag = 1;
//    }
//
//    if (!street_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
//        e_street.requestFocus();
//        e_street.setError("Invalid");
//        flag = 1;
//    }
//
//    if (street_txt.length() == 0) {
//        e_street.requestFocus();
//        e_street.setError("Field cannot be empty");
//        flag = 1;
//    }
//
//    if (!state_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
//        e_state.requestFocus();
//        e_state.setError("Invalid");
//        flag = 1;
//    }
//
//    if (state_txt.length() == 0) {
//        e_state.requestFocus();
//        e_state.setError("Field cannot be empty");
//        flag = 1;
//    }
//
//    if (!city_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
//        e_city.requestFocus();
//        e_city.setError("Invalid");
//        flag = 1;
//    }
//
//    if (!country_txt.matches("[A-Z]([a-z]*|A-Z]*)")) {
//        e_country.requestFocus();
//        e_country.setError("Invalid");
//        flag = 1;
//    }
//
//    if (country_txt.length() == 0) {
//        e_country.requestFocus();
//        e_country.setError("Field cannot be empty");
//        flag = 1;
//    }
//    if (!zipcode_txt.matches("^[1-9][0-9]{2}\\s?[0-9]{3}$")) {
//        e_zipcode.requestFocus();
//        e_zipcode.setError("Invalid Zipcode");
//        flag = 1;
//    }
//    if (zipcode_txt.length() != 6) {
//        e_zipcode.requestFocus();
//        e_zipcode.setError("Please enter 6 digit number only");
//        flag = 1;
//    }
//
//    if (!marital_txt.equals("Married")&& !marital_txt.equals("Unmarried")&&!marital_txt.equals("married")&&!marital_txt.equals("unmarried")) {
//        e_marital.requestFocus();
//        e_marital.setError("Invalid");
//        flag = 1;
//    }
//
//    if (marital_txt.length() == 0) {
//        e_marital.requestFocus();
//        e_marital.setError("Field cannot be empty");
//        flag = 1;
//    }
//    if (!aadhar_txt.matches("^[2-9][0-9]{3}[0-9]{4}[0-9]{4}$")) {
//        e_aadhar.requestFocus();
//        e_aadhar.setError("Invalid Aadhar");
//        flag = 1;
//    }
//
//    if (aadhar_txt.length() != 12) {
//        e_aadhar.requestFocus();
//        e_aadhar.setError("Aadhar is 12 digit no");
//        flag = 1;
//    }
//    if (!father_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
//        e_father.requestFocus();
//        e_father.setError("Invalid");
//        flag = 1;
//    }
//    if (father_txt.length() == 0) {
//        e_father.requestFocus();
//        e_father.setError("Field cannot be empty");
//        flag = 1;
//    }
//    if (!mother_txt.matches("[A-Z]([a-z]*[A-Z]*)")) {
//        e_mother.requestFocus();
//        e_mother.setError("Invalid");
//        flag = 1;
//    }
//    if (mother_txt.length() == 0) {
//        e_mother.requestFocus();
//        e_mother.setError("Field cannot be empty");
//        flag = 1;
//    }
//    if (!pan_txt.matches("[A-Z]{5}[0-9]{4}[A-Z]")) {
//        e_pan.requestFocus();
//        e_pan.setError("Invalid Aadhar");
//        flag = 1;
//    }
//    if (pan_txt.length() != 10) {
//        e_pan.requestFocus();
//        e_pan.setError("Length should be 10");
//        flag = 1;
//    }
//    if (!bloodgroup_txt.matches("(A|B|AB|O)[+-]")) {
//        e_bloodgroup.requestFocus();
//        e_bloodgroup.setError("Invalid");
//        flag = 1;
//    }
//    if (bloodgroup_txt.length() == 0) {
//        e_bloodgroup.requestFocus();
//        e_bloodgroup.setError("Field cannot be empty");
//        flag = 1;
//    }
//
//
//if(flag==0){
    saveData(); // Only if all the data entered by user is valid, it will be saved





}

public void saveData() {

//Creating an object of class EmployeeData
    EmployeeData model = new EmployeeData();

    String voterid_txt = e_voterid.getText().toString().trim();
    String firstname_txt = e_firstname.getText().toString().trim();
    String lastname_txt = e_lastname.getText().toString().trim();
    String age_txt = e_age.getText().toString().trim();
    String bloodgroup_txt = e_bloodgroup.getText().toString().trim();
    String dob_txt = e_dob.getText().toString().trim();
    String phone_txt = e_phone.getText().toString().trim();
    String email_txt = e_email.getText().toString().trim();
    String street_txt = e_street.getText().toString().trim();
    String city_txt = e_city.getText().toString().trim();
    String state_txt = e_state.getText().toString().trim();
    String country_txt = e_country.getText().toString().trim();
    String zipcode_txt = e_zipcode.getText().toString().trim();
    String marital_txt = e_marital.getText().toString().trim();
    String aadhar_txt = e_aadhar.getText().toString().trim();
    String pan_txt = e_pan.getText().toString().trim();
    String father_txt = e_father.getText().toString().trim();
    String mother_txt = e_mother.getText().toString().trim();

    //Initializing the variables of the object of class
    model.setVoterid(voterid_txt);
    model.setFirstname(firstname_txt);
    model.setLastname(lastname_txt);
    model.setAge(age_txt);
    model.setBloodgroup(bloodgroup_txt);
    model.setDob(dob_txt);
    model.setPhone(phone_txt);
    model.setEmail(email_txt);
    model.setStreet(street_txt);
    model.setCity(city_txt);
    model.setState(state_txt);
    model.setCountry(country_txt);
    model.setZipcode(zipcode_txt);
    model.setMarital(marital_txt);
    model.setAadhar(aadhar_txt);
    model.setPan(pan_txt);
    model.setFather(father_txt);
    model.setMother(mother_txt);

    //Inserting the data stored in the object to the database
    long s = DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

   //Makes the input fields blank again
    e_voterid.setText("");
    e_firstname.setText("");
    e_lastname.setText("");
    e_age.setText("");
    e_bloodgroup.setText("");
    e_dob.setText("");
    e_phone.setText("");
    e_aadhar.setText("");
    e_pan.setText("");
    e_email.setText("");
    e_street.setText("");
    e_state.setText("");
    e_city.setText("");
    e_country.setText("");
    e_marital.setText("");
    e_father.setText("");
    e_mother.setText("");
    e_zipcode.setText("");

    if (s == -1)//If duplicate data is entered by user
        Toast.makeText(this, "Duplicate data", Toast.LENGTH_SHORT).show();
    else {
        Toast.makeText(this, "Data Successfully Saved", Toast.LENGTH_SHORT).show();


    }
}}


