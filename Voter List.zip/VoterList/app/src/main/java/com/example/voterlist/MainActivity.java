package com.example.voterlist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {
    Button enroll,list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enroll=findViewById(R.id.button);
        list=findViewById(R.id.button2);
        enroll.setOnClickListener((view)->{  startActivity(new Intent(getApplicationContext(), Form.class));});

//       enroll.setOnClickListener(new View.OnClickListener() {
//           @Override
//           public void onClick(View view) {
//               DatabaseClass.getDatabase(getApplicationContext()).getDao().deleteall();
//           }
//       });

        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), DisplayData.class));
            }
        });



    }
}