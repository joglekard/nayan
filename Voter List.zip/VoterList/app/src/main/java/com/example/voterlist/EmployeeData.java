package com.example.voterlist;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class EmployeeData {

    @PrimaryKey
    @NonNull
    public String id;
    private String firstname;
    private String lastname;
    private String age;
    private String bloodgroup;



    public String getid()
    {
        return this.id;
    }

    public void setid(String id) {
        this.id = id;
    }

    public String getFirstname() {
        return this.firstname;
    }

    public void setFirstname(String Firstname) {
        this.firstname = Firstname;
    }
    public String getLastname() {
        return this.lastname;
    }

    public void setLastname(String Lastname) {
        this.lastname = Lastname;
    }
    public String getAge() {
        return this.age;
    }

    public void setAge(String Age) {
        this.age = Age;
    }
   public String getBloodgroup() {
        return this.bloodgroup;
    }

    public void setBloodgroup(String Bloodgroup) {
        this.bloodgroup = Bloodgroup;}
public String getList()
{
    return("ID:" + id +"  "+ firstname + " "+ lastname+ "  "+ "Age:"+ age);
}


    public EmployeeData(String id, String Firstname, String Lastname, String Age, String Bloodgroup)
    {
        this.id= id;
        this.firstname =Firstname;
        this.lastname=Lastname;
        this.age=Age;
        this.bloodgroup=Bloodgroup;
    }
    public EmployeeData()
    {
        this.id= null;
        this.firstname =null;
        this.lastname=null;
        this.age=null;
       this.bloodgroup=null;
    }
    public EmployeeData(String id, String Firstname, String Lastname, String Age)
    {
        this.id= id;
        this.firstname =Firstname;
        this.lastname=Lastname;
        this.age=Age;

    }

}
