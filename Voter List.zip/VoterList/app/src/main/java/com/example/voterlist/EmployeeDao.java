package com.example.voterlist;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface EmployeeDao {
    @Insert
    void insertAllData(EmployeeData model);

    //Select All Data
   /* @Query("select id from EmployeeData")
    String getid(String id); */

    @Query("select id from  EmployeeData")
    List<EmployeeData> getAllid();

    @Query("select * from  EmployeeData")
    List<EmployeeData> getAllData();

    @Query("Select Firstname from  EmployeeData where id like :id")
    String getFirstName(String id);

    @Query("Select Lastname from  EmployeeData where id like :id")
    String getLastname(String id);

    @Query("Select Age from  EmployeeData where id like :id")
    String getAge(String id);

   /* @Query("Select Bloodgroup from  EmployeeData where id like :id")
    String getBloodgroup(String id); */

    @Query("Select id,Firstname,Lastname,Age from  EmployeeData")
    List<EmployeeData> getListData();

    @Query("delete from EmployeeData")
    void deleteall();

}

