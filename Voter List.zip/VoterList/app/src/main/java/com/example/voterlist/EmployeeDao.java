package com.example.voterlist;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface EmployeeDao {

    //Inserts data into the table
    @Insert(onConflict= OnConflictStrategy.IGNORE)//Ignores the row if there is conflict
    long insertAllData(EmployeeData model);

   /* //Select All Data
    @Query("select id from EmployeeData")
    String getid(String id); */


    //Select the row using the id
    @Query("Select * from  EmployeeData where id like :id")
    LiveData<EmployeeData> getRow(int id);

    @Query("Select id,voterid,firstname,lastname,age from  EmployeeData")
    LiveData<List<EmployeeData>> getListData();



//

//    //Select some specific columns from the table
//    @Query("Select id,Voterid,Firstname,Lastname,Age from  EmployeeData")
//    List<EmployeeData> getListData();

    

}

