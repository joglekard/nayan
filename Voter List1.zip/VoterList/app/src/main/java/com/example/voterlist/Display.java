package com.example.voterlist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;


public class Display extends MainActivity {



    //   private ArrayList<RecyclerData> al;
    //private List<RecyclerData> list;
    private ArrayList<RecyclerData> recyclerDataArrayList;
    private RecyclerView recyclerview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclergrid);
        recyclerview = findViewById(R.id.review_grid);
        Intent i= getIntent();
        int title= i.getIntExtra("title",0);
        getData(title);
        display();



    }

    private void getData(int id) {
        recyclerDataArrayList = new ArrayList<>();

        recyclerDataArrayList.add(new RecyclerData("Voter ID",DatabaseClass.getDatabase(getApplicationContext()).getDao().getVoterid(id)));
        recyclerDataArrayList.add(new RecyclerData("First Name", DatabaseClass.getDatabase(getApplicationContext()).getDao().getFirstName(id)));
        recyclerDataArrayList.add(new RecyclerData("Last Name", DatabaseClass.getDatabase(getApplicationContext()).getDao().getLastname(id)));
        recyclerDataArrayList.add(new RecyclerData("Father's Name", DatabaseClass.getDatabase(getApplicationContext()).getDao().getFather(id)));
        recyclerDataArrayList.add(new RecyclerData("Mother's Name", DatabaseClass.getDatabase(getApplicationContext()).getDao().getMother(id)));
        recyclerDataArrayList.add(new RecyclerData("Age", DatabaseClass.getDatabase(getApplicationContext()).getDao().getAge(id)));
        recyclerDataArrayList.add(new RecyclerData("Marital Status", DatabaseClass.getDatabase(getApplicationContext()).getDao().getMarital(id)));
        recyclerDataArrayList.add(new RecyclerData("Bloodgroup", DatabaseClass.getDatabase(getApplicationContext()).getDao().getBloodgroup(id)));
        recyclerDataArrayList.add(new RecyclerData("Phone", DatabaseClass.getDatabase(getApplicationContext()).getDao().getPhone(id)));
        recyclerDataArrayList.add(new RecyclerData("Email", DatabaseClass.getDatabase(getApplicationContext()).getDao().getEmail(id)));
        recyclerDataArrayList.add(new RecyclerData("Date of birth", DatabaseClass.getDatabase(getApplicationContext()).getDao().getDob(id)));
        recyclerDataArrayList.add(new RecyclerData("Street", DatabaseClass.getDatabase(getApplicationContext()).getDao().getStreet(id)));
        recyclerDataArrayList.add(new RecyclerData("City", DatabaseClass.getDatabase(getApplicationContext()).getDao().getCity(id)));
        recyclerDataArrayList.add(new RecyclerData("State", DatabaseClass.getDatabase(getApplicationContext()).getDao().getState(id)));
        recyclerDataArrayList.add(new RecyclerData("Country", DatabaseClass.getDatabase(getApplicationContext()).getDao().getCountry(id)));
        recyclerDataArrayList.add(new RecyclerData("Zipcode", DatabaseClass.getDatabase(getApplicationContext()).getDao().getZipcode(id)));
        recyclerDataArrayList.add(new RecyclerData("Aadhar no.", DatabaseClass.getDatabase(getApplicationContext()).getDao().getAadhar(id)));
        recyclerDataArrayList.add(new RecyclerData("Pan no.", DatabaseClass.getDatabase(getApplicationContext()).getDao().getPan(id)));



           /*if(Hideage.isChecked()) {
               recyclerDataArrayList.remove(2);
            recyclerDataArrayList.add(new RecyclerData(DatabaseClass.getDatabase(getApplicationContext()).getDao().getFirstName(id), DatabaseClass.getDatabase(getApplicationContext()).getDao().getLastname(id),DatabaseClass.getDatabase(getApplicationContext()).getDao().getk(id),DatabaseClass.getDatabase(getApplicationContext()).getDao().getAge(id)));

        }


   private void getData() {
        list = new ArrayList<>();
        list = DatabaseClass.getDatabase(getApplicationContext()).getDao().getAllData();
        al=new ArrayList<>();
        al.addAll(list);


        // added data from arraylist to adapter class.
        RecyclerViewAdapter adapter=new RecyclerViewAdapter(al,this);

        // setting grid layout manager to implement grid view.
        // in this method '2' represents number of columns to be displayed in grid view.
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);

        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);

    }*/





    }

    private void display() {
        // added data from arraylist to adapter class.
        DetailsAdapter adapter = new DetailsAdapter(recyclerDataArrayList, this);

        // setting grid layout manager to implement grid view.
        // in this method '2' represents number of columns to be displayed in grid view.
        GridLayoutManager layoutManager = new GridLayoutManager(this,2);

        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);
    }



}

