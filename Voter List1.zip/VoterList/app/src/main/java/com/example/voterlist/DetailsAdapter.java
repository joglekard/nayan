package com.example.voterlist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
public class  DetailsAdapter extends RecyclerView.Adapter<DetailsAdapter.RecyclerViewHolder2> {

    private Context mcontext;
    ArrayList<RecyclerData> list2;




    public DetailsAdapter(ArrayList<RecyclerData> list, Context mcontext) {

        this.mcontext = mcontext;
        this.list2 = list;
    }

    @NonNull
    @Override
    public RecyclerViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.gridcard_layout, parent, false);
        return new RecyclerViewHolder2(view);

    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder2 holder, int position) {
        RecyclerData recyclerData = list2.get(position);

        holder.T1.setText(recyclerData.getTitle1());
        holder.T2.setText(recyclerData.getTitle2());
    }
    @Override
    public int getItemCount() {
        // this method returns the size of recyclerview
        return list2.size();
    }
    // View Holder Class to handle Recycler View.
    public class RecyclerViewHolder2 extends RecyclerView.ViewHolder {
        private TextView T1;
        private TextView T2;


        public RecyclerViewHolder2(@NonNull View itemView) {
            super(itemView);
            T1 = itemView.findViewById(R.id.text1);
            T2 = itemView.findViewById(R.id.text2);
        }}}


