package com.example.voterlist;

import android.content.Intent;
import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class Display extends MainActivity {



    //   private ArrayList<RecyclerData> al;
    //private List<RecyclerData> list;
    private ArrayList<RecyclerData> recyclerDataArrayList;
    private RecyclerView recyclerview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclergrid);
        recyclerview = findViewById(R.id.review_grid);
        Intent i= getIntent();
        int title= i.getIntExtra("title",0);
        getData(title);
        display();




    }

    private void getData(int id) {

        recyclerDataArrayList = new ArrayList<>();

       // Creating an object of class EmployeeData and fetching and storing a database record in it using row id.
        EmployeeData s= DatabaseClass.getDatabase(getApplicationContext()).getDao().getRow(id);

       // Adding the titles and values in Arraylist
        recyclerDataArrayList.add(new RecyclerData("Voter ID", s.getVoterid()));
        recyclerDataArrayList.add(new RecyclerData("First Name", s.getFirstname()));
        recyclerDataArrayList.add(new RecyclerData("Last Name", s.getLastname()));
        recyclerDataArrayList.add(new RecyclerData("Father's Name", s.getFather()));
        recyclerDataArrayList.add(new RecyclerData("Mother's Name", s.getMother()));
        recyclerDataArrayList.add(new RecyclerData("Age", s.getAge()));
        recyclerDataArrayList.add(new RecyclerData("Marital Status", s.getMarital()));
        recyclerDataArrayList.add(new RecyclerData("Bloodgroup", s.getBloodgroup()));
        recyclerDataArrayList.add(new RecyclerData("Phone", s.getPhone()));
        recyclerDataArrayList.add(new RecyclerData("Email", s.getEmail()));
        recyclerDataArrayList.add(new RecyclerData("Date of birth", s.getDob()));
        recyclerDataArrayList.add(new RecyclerData("Street", s.getStreet()));
        recyclerDataArrayList.add(new RecyclerData("City", s.getCity()));
        recyclerDataArrayList.add(new RecyclerData("State", s.getState()));
        recyclerDataArrayList.add(new RecyclerData("Country", s.getCountry()));
        recyclerDataArrayList.add(new RecyclerData("Zipcode", s.getZipcode()));
        recyclerDataArrayList.add(new RecyclerData("Aadhar no.", s.getAadhar()));
        recyclerDataArrayList.add(new RecyclerData("Pan no.", s.getPan()));



           /*if(Hideage.isChecked()) {
               recyclerDataArrayList.remove(2);
            recyclerDataArrayList.add(new RecyclerData(DatabaseClass.getDatabase(getApplicationContext()).getDao().getFirstName(id), DatabaseClass.getDatabase(getApplicationContext()).getDao().getLastname(id),DatabaseClass.getDatabase(getApplicationContext()).getDao().getk(id),DatabaseClass.getDatabase(getApplicationContext()).getDao().getAge(id)));

        }


   private void getData() {
        list = new ArrayList<>();
        list = DatabaseClass.getDatabase(getApplicationContext()).getDao().getAllData();
        al=new ArrayList<>();
        al.addAll(list);


        // added data from arraylist to adapter class.
        RecyclerViewAdapter adapter=new RecyclerViewAdapter(al,this);

        // setting grid layout manager to implement grid view.
        // in this method '2' represents number of columns to be displayed in grid view.
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);

        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);

    }*/





    }

    private void display() {
        // added data from arraylist to adapter class.
        DetailsAdapter adapter = new DetailsAdapter(recyclerDataArrayList);

        // setting grid layout manager to implement grid view.
        // in this method '2' represents number of columns to be displayed in grid view.
        GridLayoutManager layoutManager = new GridLayoutManager(this,2);

        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);
    }



}

