package com.example.voterlist;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface EmployeeDao {

    //Inserts data into the table
    @Insert(onConflict= OnConflictStrategy.IGNORE)//Ignores the row if there is conflict
    long insertAllData(EmployeeData model);

   /* //Select All Data
    @Query("select id from EmployeeData")
    String getid(String id); */

    /*@Query("select id from  EmployeeData")
    List<EmployeeData> getAllid();

    @Query("select * from  EmployeeData")
    List<EmployeeData> getAllData();

    @Query("Select id from  EmployeeData where id like :id")
    int getId(int id);*/

    //Select the row using the id
    @Query("Select * from  EmployeeData where id like :id")
   EmployeeData getRow(int id);

    @Query("Select id,voterid,firstname,lastname,age from  EmployeeData")
    List<EmployeeData> getListData();

    @Query("select * from  EmployeeData")
    LiveData<List<EmployeeData>> getAllData();

//    @Query("Select voterid from  EmployeeData where id like :id")
//    String getVoterid(int id);
//
//    @Query("Select firstname from  EmployeeData where id like :id")
//    String getFirstName(int id);
//
//    @Query("Select lastname from  EmployeeData where id like :id")
//    String getLastname(int id);
//
//    @Query("Select age from  EmployeeData where id like :id")
//    String getAge(int id);
//
//    @Query("Select bloodgroup from  EmployeeData where id like :id")
//    String getBloodgroup(int id);
//
//    @Query("Select father from  EmployeeData where id like :id")
//    String getFather(int id);
//
//    @Query("Select mother from  EmployeeData where id like :id")
//    String getMother(int id);
//
//    @Query("Select phone from  EmployeeData where id like :id")
//    String getPhone(int id);
//
//    @Query("Select dob from  EmployeeData where id like :id")
//    String getDob(int id);
//
//    @Query("Select street from  EmployeeData where id like :id")
//    String getStreet(int id);
//
//    @Query("Select city from  EmployeeData where id like :id")
//    String getCity(int id);
//
//    @Query("Select state from  EmployeeData where id like :id")
//    String getState(int id);
//
//    @Query("Select country from  EmployeeData where id like :id")
//    String getCountry(int id);
//
//    @Query("Select email from  EmployeeData where id like :id")
//    String getEmail(int id);
//
//    @Query("Select aadhar from  EmployeeData where id like :id")
//    String getAadhar(int id);
//
//    @Query("Select pan from  EmployeeData where id like :id")
//    String getPan(int id);
//
//    @Query("Select zipcode from  EmployeeData where id like :id")
//    String getZipcode(int id);
//
//    @Query("Select marital from  EmployeeData where id like :id")
//    String getMarital(int id);

//    //Select some specific columns from the table
//    @Query("Select id,Voterid,Firstname,Lastname,Age from  EmployeeData")
//    List<EmployeeData> getListData();

    

}

