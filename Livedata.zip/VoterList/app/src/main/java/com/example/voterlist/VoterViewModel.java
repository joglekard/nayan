package com.example.voterlist;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class VoterViewModel extends ViewModel {
//    private EmployeeDao employeedao;
//    private DatabaseClass databaseclass;
//    private LiveData<List<EmployeeData>> alldata;
//
//    public VoterViewModel(Application application)
//    {
//        super(application);
//        databaseclass= DatabaseClass.getDatabase(application);
//        employeedao= databaseclass.getDao();
//        alldata= employeedao.getAllData();
//    }
//    public LiveData<List<EmployeeData>> getAlldata() {
//        return alldata;
public Context context;
public MutableLiveData<List<EmployeeData>> viewlist;
public MutableLiveData<List<EmployeeData>>viewget()
    {

if(viewlist==null)
    viewlist =new MutableLiveData<>();
        //Retrieving some specific data from database and storing it in list

        viewlist.setValue( DatabaseClass.getDatabase(getContext()).getDao().getListData());
        return viewlist;
    }

    public Context getContext() {
        return context;
    }
    public void setContext(Context context)
    {
        this.context=context;
    }
    public VoterViewModel()
    {
        this.context=null;
    }

}




