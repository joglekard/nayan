package com.example.voterlist;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
public class  RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {

   final List<EmployeeData> list;




    public RecyclerViewAdapter(List<EmployeeData> list) {

        this.list = list;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listcard_layout, parent, false);
        return new RecyclerViewHolder(view);

    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        // Set the data to textview

        holder.T1.setText(list.get(position).getList());
    }

    @Override
    public int getItemCount() {
        // this method returns the size of recyclerview
        return list.size();
    }

    // View Holder Class to handle Recycler View.
    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private final TextView T1;


        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            //Method to send row id to another activity on the click of a list
            itemView.setOnClickListener(v -> {
                Intent i = new Intent(v.getContext(), Display.class);
                i.putExtra("title",list.get(getAdapterPosition()).getId());
                v.getContext().startActivity(i);

            });
            T1 = itemView.findViewById(R.id.text1);


        }
    }
}


