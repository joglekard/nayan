package com.example.createdb;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName ="Employee" )
public class RecyclerData {

@PrimaryKey
@NonNull
private String title1;
private String title2;

    public String getTitle1() {
        return title1;
    }

    public void setTitle1(String key) {
        this.title1 = title1;
    }

    public String getTitle2() {
        return title2;
    }

    public void setTitle2(String title2) {
        this.title2 = title2;
    }


   public RecyclerData() {
        this.title1 = title1;
        this.title2 = title2; }
}