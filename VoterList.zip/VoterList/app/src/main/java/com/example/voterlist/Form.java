package com.example.voterlist;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Form  extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5;
    Button save,back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        e1=findViewById(R.id.edit_text1);
        e2=findViewById(R.id.edit_text2);
        e3=findViewById(R.id.edit_text3);
        e4=findViewById(R.id.edit_text4);
        e5=findViewById(R.id.edit_text5);

        save=findViewById(R.id.save);
        back=findViewById(R.id.back);

        save.setOnClickListener((view)->{saveData();});
}
private void saveData(){

        EmployeeData model = new EmployeeData();
    String id_txt = e1.getText().toString().trim();
    String firstname_txt = e2.getText().toString().trim();
    String lastname_txt = e3.getText().toString().trim();
    String age_txt = e4.getText().toString().trim();
    String bloodgroup_txt = e5.getText().toString().trim();


    model.setid(id_txt);
    model.setFirstname(firstname_txt);
    model.setLastname(lastname_txt);
    model.setAge(age_txt);
    model.setBloodgroup(bloodgroup_txt);

    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

    e1.setText("");
    e2.setText("");
    e3.setText("");
    e4.setText("");
    e5.setText("");
    // age.setText("");
    Toast.makeText(this, "Data Successfully Saved", Toast.LENGTH_SHORT).show();

}
}


