package com.example.voterlist;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class EmployeeData {

    @PrimaryKey
    @NonNull
    public String id;
    private String Firstname;
    private String Lastname;
    private String Age;
    private String Bloodgroup;

    public String getid()
    {
        return this.id;
    }

    public void setid(String id) {
        this.id = id;
    }

    public String getFirstname() {
        return this.Firstname;
    }

    public void setFirstname(String Firstname) {
        this.Firstname = Firstname;
    }
    public String getLastname() {
        return this.Lastname;
    }

    public void setLastname(String Lastname) {
        this.Lastname = Lastname;
    }
    public String getAge() {
        return this.Age;
    }

    public void setAge(String Age) {
        this.Age = Age;
    }
    public String getBloodgroup() {
        return this.Bloodgroup;
    }

    public void setBloodgroup(String Bloodgroup) {
        this.Bloodgroup = Bloodgroup;
    }


    public EmployeeData(String id, String Firstname, String Lastname, String Age, String Bloodgroup)
    {
        this.id= id;
        this.Firstname =Firstname;

        this.Lastname=Lastname;
        this.Age=Age;
        this.Bloodgroup=Bloodgroup;
    }
    public EmployeeData()
    {
        this.id= null;
        this.Firstname =null;
        this.Lastname=null;
        this.Age=null;
        this.Bloodgroup=null;
    }

}
