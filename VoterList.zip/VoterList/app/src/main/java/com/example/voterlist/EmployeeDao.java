package com.example.voterlist;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
@Dao
public interface EmployeeDao {
    @Insert
    void insertAllData(EmployeeData model);

   /* //Select All Data
    @Query("select * from  EmployeeData")
    List<EmployeeData> getAllData();*/

    @Query("Select Firstname from  EmployeeData where id like :id")
    String getFirstName(int id);

    @Query("Select Lastname from  EmployeeData where id like :id")
    String getLastname(int id);

    @Query("Select Age from  EmployeeData where id like :id")
    String getAge(int id);

    @Query("Select Bloodgroup from  EmployeeData where id like :id")
    String getBloodgroup(int id);

    @Query("delete from EmployeeData")
    void deleteall();

}

