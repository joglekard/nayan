package com.example.voterlist;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.voterlist.Adapter.RecyclerViewAdapter;
import com.example.voterlist.Entity.EmployeeData;
import com.example.voterlist.ViewModel.VoterViewModel;

import java.util.List;


public class MainActivity extends AppCompatActivity {


    private RecyclerView recyclerview;
    VoterViewModel voterViewModel;

    @Override
    //adding add button
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.addbutton, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // handle button activities
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.mybutton) {
            // do something here
            startActivity(new Intent(getApplicationContext(), Form.class));
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onCreate(Bundle savedinstanceState) {
        super.onCreate(savedinstanceState);
        voterViewModel= ViewModelProviders.of(this).get(VoterViewModel.class);
        setContentView(R.layout.activity_main);
        recyclerview = findViewById(R.id.review_list);
        getData_list();//Method to fetch key details of users from database
    }

    private void getData_list() {
        voterViewModel.viewgetlist().observe(this, new Observer<List<EmployeeData>>() {
            @Override
            public void onChanged(List<EmployeeData> employeeData) {
                display_list(employeeData);//Method to diplay list of users
            }
        });
    }

    private void display_list(List<EmployeeData>e) {
        //added data from list to adapter class
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(e);
        // setting linear layout manager to implement linear view.
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);
    }
}