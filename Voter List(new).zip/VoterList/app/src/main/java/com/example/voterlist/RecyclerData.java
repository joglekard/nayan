package com.example.voterlist;


public class RecyclerData {

    private final String title1;
    private final String title2;

    public String getTitle1() {
        return title1;
    }

    public String getTitle2() {
        return title2;
    }


    public RecyclerData(String title1, String title2) {
        this.title1 = title1;
        this.title2 = title2;

    }
}

