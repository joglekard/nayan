package com.example.voterlist.Repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.voterlist.Dao.EmployeeDao;
import com.example.voterlist.Database.DatabaseClass;
import com.example.voterlist.Entity.EmployeeData;

import java.util.List;

public class VoterRepository {

    private EmployeeDao employeeDao;
    private LiveData<List<EmployeeData>> listData;
    private LiveData<EmployeeData> edata;

    public VoterRepository(Application application) {

        employeeDao = DatabaseClass.getDatabase(application).getDao();
    }

    public LiveData<List<EmployeeData>> getListData() {
        listData = employeeDao.getListData();
        return listData;
    }

    public LiveData<EmployeeData> getdatabyId(int id) {
        edata = employeeDao.getRow(id);
        return edata;
    }

    public void insert(EmployeeData employeeData) {
        new InsertAsyncTask((employeeDao)).execute(employeeData);

    }

    private static class InsertAsyncTask extends AsyncTask<EmployeeData, Void, Void> {
        private EmployeeDao employeedao;

        private InsertAsyncTask(EmployeeDao employeedao) {
            this.employeedao = employeedao;
        }

        @Override
        protected Void doInBackground(EmployeeData... employeeData) {
            employeedao.insertAllData(employeeData[0]);

            return null;
        }
    }
}