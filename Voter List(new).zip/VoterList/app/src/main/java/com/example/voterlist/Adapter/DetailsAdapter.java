package com.example.voterlist.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.voterlist.R;
import com.example.voterlist.RecyclerData;

import java.util.ArrayList;
public class  DetailsAdapter extends RecyclerView.Adapter<DetailsAdapter.RecyclerViewHolder2> {

    final ArrayList<RecyclerData> list;
    public DetailsAdapter(ArrayList<RecyclerData> list) {

        this.list = list;
    }

    @NonNull
    @Override
    public RecyclerViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.gridcard_layout, parent, false);
        return new RecyclerViewHolder2(view);
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder2 holder, int position) {
        // Set the data to textview

        RecyclerData recyclerData = list.get(position);

        holder.Title.setText(recyclerData.getTitle1());
        holder.Value.setText(recyclerData.getTitle2());
    }
    @Override
    public int getItemCount() {
        // this method returns the size of recyclerview
        return list.size();
    }
    // View Holder Class to handle Recycler View.
    public static class RecyclerViewHolder2 extends RecyclerView.ViewHolder {
        private final TextView Title;
        private final TextView Value;


        public RecyclerViewHolder2(@NonNull View itemView) {
            super(itemView);
            Title = itemView.findViewById(R.id.text1);
            Value = itemView.findViewById(R.id.text2);
        }
    }
}


