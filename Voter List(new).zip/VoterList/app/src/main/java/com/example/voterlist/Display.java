package com.example.voterlist;

import android.content.Intent;
import android.os.Bundle;

import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.voterlist.Adapter.DetailsAdapter;
import com.example.voterlist.Entity.EmployeeData;

import java.util.ArrayList;


public class Display extends MainActivity {



    //   private ArrayList<RecyclerData> al;
    //private List<RecyclerData> list;
    private ArrayList<RecyclerData> recyclerDataArrayList;
    private RecyclerView recyclerview;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclergrid);
        recyclerview = findViewById(R.id.review_grid);
        Intent i= getIntent();
        int id= i.getIntExtra("unique-id",0);
        getData_list(id);//Method to fetch key details of users from database

    }

    private void getData_list(int id) {
        voterViewModel.viewDetails(id).observe(this, new Observer<EmployeeData>() {
            @Override
            public void onChanged(EmployeeData employeeData)
            {

                 recyclerDataArrayList = new ArrayList<>();
        recyclerDataArrayList.add(new RecyclerData("Voter ID", employeeData.getVoterid()));
        recyclerDataArrayList.add(new RecyclerData("First Name", employeeData.getFirstname()));
        recyclerDataArrayList.add(new RecyclerData("Last Name", employeeData.getLastname()));
        recyclerDataArrayList.add(new RecyclerData("Father's Name", employeeData.getFather()));
        recyclerDataArrayList.add(new RecyclerData("Mother's Name", employeeData.getMother()));
        recyclerDataArrayList.add(new RecyclerData("Age", employeeData.getAge()));
        recyclerDataArrayList.add(new RecyclerData("Marital Status", employeeData.getMarital()));
        recyclerDataArrayList.add(new RecyclerData("Bloodgroup", employeeData.getBloodgroup()));
        recyclerDataArrayList.add(new RecyclerData("Phone", employeeData.getPhone()));
        recyclerDataArrayList.add(new RecyclerData("Email", employeeData.getEmail()));
        recyclerDataArrayList.add(new RecyclerData("Date of birth", employeeData.getDob()));
        recyclerDataArrayList.add(new RecyclerData("Street", employeeData.getStreet()));
        recyclerDataArrayList.add(new RecyclerData("City", employeeData.getCity()));
        recyclerDataArrayList.add(new RecyclerData("State", employeeData.getState()));
        recyclerDataArrayList.add(new RecyclerData("Country", employeeData.getCountry()));
        recyclerDataArrayList.add(new RecyclerData("Zipcode", employeeData.getZipcode()));
        recyclerDataArrayList.add(new RecyclerData("Aadhar no.", employeeData.getAadhar()));
        recyclerDataArrayList.add(new RecyclerData("Pan no.", employeeData.getPan()));
          display(recyclerDataArrayList);
            }


        });

    }




    private void display( ArrayList<RecyclerData> recyclerDataArrayList)  {
        // added data from arraylist to adapter class.
        DetailsAdapter adapter = new DetailsAdapter(recyclerDataArrayList);

        // setting grid layout manager to implement grid view.
        // in this method '2' represents number of columns to be displayed in grid view.
        GridLayoutManager layoutManager = new GridLayoutManager(this,2);

        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);
    }



}

